```sql
-- =====================================================
-- Student Records Management System
-- Database: student_information_system
-- MySQL Version: 8.0+
-- =====================================================

CREATE DATABASE IF NOT EXISTS student_information_system;

USE student_information_system;

-- Disable foreign key checks while recreating the tables.
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================
-- USERS TABLE
-- Stores registered user accounts.
-- =====================================================

CREATE TABLE users (
    user_id INT NOT NULL AUTO_INCREMENT,
    username VARCHAR(30) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,

    PRIMARY KEY (user_id),
    UNIQUE KEY uq_users_username (username)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_0900_ai_ci;

-- =====================================================
-- STUDENTS TABLE
-- Stores student records belonging to each user.
-- =====================================================

CREATE TABLE students (
    student_id VARCHAR(50) NOT NULL,
    user_id INT NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    course VARCHAR(100) NOT NULL,
    year_level VARCHAR(20) NOT NULL,

    PRIMARY KEY (student_id),

    KEY idx_students_user_id (user_id),

    CONSTRAINT fk_students_users
        FOREIGN KEY (user_id)
        REFERENCES users (user_id)
        ON DELETE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_0900_ai_ci;

-- =====================================================
-- SAMPLE USER
-- This is a demonstration account, not a login account.
-- Register an account through the application before
-- using the sample student records.
-- =====================================================

INSERT INTO users (user_id, username, password_hash)
VALUES (1, 'demo_user', 'REPLACE_WITH_A_REAL_PASSWORD_HASH');

-- =====================================================
-- SAMPLE STUDENT RECORDS
-- These records belong to user_id = 1.
-- =====================================================

INSERT INTO students
    (student_id, user_id, full_name, course, year_level)
VALUES
    ('2026-001', 1, 'Juan Dela Cruz',
     'BS Computer Science', '1st Year'),

    ('2026-002', 1, 'Maria Santos',
     'BS Information Technology', '2nd Year'),

    ('2026-003', 1, 'Pedro Reyes',
     'BS Computer Science', '3rd Year');

-- =====================================================
-- END OF DATABASE SETUP
-- =====================================================
```
